package com.assignment;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class Dashboard extends Activity {
	public static final String TABLE_NAME = "employee";

	TextView n;
	TextView e;
	TextView p;
	Button ed;
	Data d;
	ImageButton l;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dashboard);
		n = (TextView) findViewById(R.id.tvname);
		e = (TextView) findViewById(R.id.tvemail);
		p = (TextView) findViewById(R.id.tvphone);
		ed =(Button)findViewById(R.id.edit);
		l=(ImageButton)findViewById(R.id.btnlogout);
		d = new Data(getApplicationContext());
		
		
		l.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 Intent login = new Intent(getApplicationContext(), Login.class);  
				   startActivity(login);
				   overridePendingTransition(R.animator.animation1, R.animator.animation2);
				   finish();
			}
		});
		
		
		Intent intent = getIntent();
		String name = intent.getExtras().getString("NAME");
		
		boolean flag = false;
		String da = "SELECT * FROM " + TABLE_NAME;
		SQLiteDatabase db = d.getReadableDatabase();
		Cursor c = db.rawQuery(da, null);
		c.moveToFirst();
		int cou = d.rcount(), i = 0;
		while (i < cou) {

			if (c.getString(0).toString().equals(name)) {
				n.setText(name);
				e.setText(c.getString(1).toString());
				p.setText(c.getString(3).toString());
			}

			c.moveToNext();
			i++;
		}
		ed.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 Intent login = new Intent(getApplicationContext(), Edit.class);  
				  login.putExtra("NAME", n.getText().toString());
				   startActivity(login);
				   overridePendingTransition(R.animator.animation1, R.animator.animation2);
				   finish();
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_dashboard, menu);
		return true;
	}

}
