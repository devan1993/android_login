package com.assignment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.TableLayout;

public class Data extends SQLiteOpenHelper{
	public static final String DATABASE_NAME="tcs";
	public static final String TABLE_NAME="employee";
	public static final String NAME="name";
	public static final String EMAIL="email";
	public static final String PASSWORD="pass";
	public static final String PHONE="phone";
	private static final int DATABASE_VERSION = 1;
	
	public Data(Context context) {
		super(context, DATABASE_NAME, null , DATABASE_VERSION);
	
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		
		String create_table = "CREATE TABLE "+ TABLE_NAME + " ( "
								+ NAME + 	" TEXT ,"
								+ EMAIL + 	" TEXT ,"
								+ PASSWORD+	" TEXT ,"
								+ PHONE + " TEXT " + ")";
		db.execSQL(create_table);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
	
		db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
		
		onCreate(db);
	}

		public void updateTable(String name, String email, String phone){
			  
			  SQLiteDatabase db = this.getWritableDatabase();
			 ContentValues values = new ContentValues();
			 values.put(EMAIL, email);
			 values.put(PHONE, phone);
			 String[] where={name};
			 db.update(TABLE_NAME, values, NAME+"=?",where);
			
		 }
	
	public void addUser(String name, String email, String password, String phone )
	{
		SQLiteDatabase db=this.getWritableDatabase();
		
		ContentValues v = new ContentValues();
		
		v.put(NAME , name);
		v.put(EMAIL , email);
		v.put(PASSWORD , password);
		v.put(PHONE , phone);

		db.insert(TABLE_NAME, null,  v);
		db.close();
	}
	
	public int rcount()
	{
		String q="SELECT * FROM "+ TABLE_NAME;
		SQLiteDatabase db  = this.getReadableDatabase();
		Cursor c= db.rawQuery(q, null);
		int n=c.getCount();
		db.close();
		c.close();
		return n;
	}
    public void resetTables(){
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete All Rows
        db.delete(TABLE_NAME, null, null);
        db.close();
    }
    
    public void loadingPage(Activity act)
    {
    	ProgressDialog pd = new ProgressDialog(act);
		pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		pd.setMessage("loading.....");
		pd.setIndeterminate(true);
		pd.setCancelable(true);
		pd.show();
    }

}
