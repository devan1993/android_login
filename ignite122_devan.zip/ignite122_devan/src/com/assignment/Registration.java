package com.assignment;




import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends Activity {
	public static final String TABLE_NAME="employee";
	EditText name;
	EditText email;
	EditText pass;
	EditText phone;
	Button submit;
	
	Button log;
	Data d;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_registration);
	
		name =(EditText)findViewById(R.id.txtname);
		email =(EditText)findViewById(R.id.txtadd);
		pass =(EditText)findViewById(R.id.txtpass);
		phone =(EditText)findViewById(R.id.txtphone);
		submit = (Button)findViewById(R.id.btnsubmit);
		log=(Button)findViewById(R.id.btnLinkToLoginScreen);
		d = new Data(getApplicationContext());
		submit.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
			
				boolean flag=false;
				
					String da="SELECT * FROM "+ TABLE_NAME;
					SQLiteDatabase db = d.getReadableDatabase();
					Cursor c= db.rawQuery(da, null);
				
					c.moveToFirst();
					int cou=d.rcount(),i=0;
					while(i<cou)
					{

						if(c.getString(0).toString().equals(name.getText().toString()))
						{
							flag=true;
							break;
						}
						
						c.moveToNext();
						i++;
					}
					if(flag==true)
					{
						Toast.makeText(getApplicationContext(),/*String.valueOf(co)*/"Username already exists!" , Toast.LENGTH_SHORT).show();
			
					}
					else
					{
						d.addUser(name.getText().toString(),email.getText().toString(),pass.getText().toString(),phone.getText().toString());
						int co=d.rcount();
						//Toast.makeText(getApplicationContext(),String.valueOf(co), Toast.LENGTH_SHORT).show();
							Intent login = new Intent(getApplicationContext(), Login.class);
						//	login.putExtra("NAME", name.getText().toString());
							startActivity(login);
							finish();
			               
					}
					
				}
				
			
		});
		
		log.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				  Intent login = new Intent(getApplicationContext(), Login.class);

				  startActivity(login);
				  finish();
			}
		});
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_registration, menu);
		return true;
	}

}
